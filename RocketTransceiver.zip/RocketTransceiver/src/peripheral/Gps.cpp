//
// Created by james on 11/16/2019.
//

#include <HardwareSerial.h>
#include "Gps.h"

void Gps::debug() {
    // TODO Write this
    Serial.println("Gps::debug");
}

void Gps::push(uint8_t* buf, uint8_t len) {
    // TODO Write this
}

void Gps::pull(uint8_t* buf, uint8_t len) {
    // TODO Write this
}
