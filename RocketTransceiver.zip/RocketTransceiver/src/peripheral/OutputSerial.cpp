//
// Created by james on 11/16/2019.
//

#include <HardwareSerial.h>
#include "OutputSerial.h"

void OutputSerial() {

}

void OutputSerial::debug() {
    // TODO Write this
    Serial.println("OutputSerial::debug");
}

void OutputSerial::push(uint8_t* buf, uint8_t len) {
    // TODO Write this
}

void OutputSerial::pull(uint8_t* buf, uint8_t len) {
    // TODO Write this
}
