//
// Created by james on 11/16/2019.
//

#include "DataLogger.h"

void DataLogger::debug() {
    // TODO Write this
}

void DataLogger::push(uint8_t* buf, uint8_t len) {
    // TODO Write this
}

void DataLogger::pull(uint8_t* buf, uint8_t len) {
    // TODO Write this
}
