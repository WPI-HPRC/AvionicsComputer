#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2019-12-21 12:55:44

#include "Arduino.h"
#include "Arduino.h"
#include "src/peripheral/LoRaCustom.h"
#include "src/peripheral/StratoLogger.h"
#include "src/peripheral/GyroAccel.h"

void setup() ;
void loop() ;

#include "RocketTransceiver.ino"


#endif
